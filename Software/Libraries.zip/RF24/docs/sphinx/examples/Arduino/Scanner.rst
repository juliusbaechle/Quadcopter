Scanner.ino
==================

.. literalinclude:: ../../../../examples/scanner/scanner.ino
    :lines: 10-
    :linenos:
    :lineno-match:
