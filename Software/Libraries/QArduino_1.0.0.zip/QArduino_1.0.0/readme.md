Simplify parallel tasks by using non preemptive scheduling and
use signals to connect static and member functions to use the observer pattern


Installation
--------------------------------------------------------------------------------

To install this library, just place this entire folder as a subfolder in your
Arduino/lib/targets/libraries folder.

Building
--------------------------------------------------------------------------------

After this library is installed, you just have to start the Arduino application.
You may see a few warning messages as it's built.

To use this library in a sketch, go to the Sketch | Import Library menu and
select Test.  This will add a corresponding line to the top of your sketch:
#include <Test.h>

To stop using this library, delete that line from your sketch.

Using Signals
--------------------------------------------------------------------------------

Using Timers & Threads
--------------------------------------------------------------------------------

Using Vector
--------------------------------------------------------------------------------